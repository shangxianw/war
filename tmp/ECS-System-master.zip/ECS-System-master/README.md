#ECS-System

A ECS(Entity Component System) system developed by javascript.

Run index.html can see a simple game developed by ecs system. 
